# 无人车国家—省—市监管驾驶舱：Cesium 精选参考包

## 1. 使用原则

本包从原 `three-cesium-examples` 中只保留对当前无人车监管驾驶舱有直接价值的 Cesium 示例。

目标不是把示例代码原样拼进项目，而是把其中的核心实现抽成现有 `GeoEngine` 的通用能力。当前项目仍以 **Cesium 为唯一主地图引擎**。

> 注意：部分原示例依赖作者外部资源地址、`FILE_HOST`、`GLOBAL_CONFIG`、第三方模型或在线 GeoJSON，因此本包定位为“源码参考包”，不是独立可运行 Demo。

## 2. 第一优先级：建议直接吸收到 GeoEngine

| 参考文件 | 可用于当前项目 | 建议封装 |
|---|---|---|
| `basic/boundBorder.js` | 国家/省行政边界发光描边 | `BoundaryLayer` / `RegionGlow` |
| `basic/geojsonFace.js` | 省域、地市区域填充与选中 | `RegionLayer` |
| `expand/gradienGeojsonFace.js` | 国家/省地图区域渐变发光 | `RegionMaterial` |
| `basic/flyLine.js` | 国家、省级跨区域流光线 | `FlowRoute` |
| `expand/transportLine.js` | 市级道路/运行线路动态流动效果 | `RouteFlowLayer` |
| `basic/routeNavigation.js` | 无人车沿轨迹运动、第三人称跟随 | `TrackAnimation` + `VehicleFollow` |
| `application/cssElementTrack.js` | 车辆运动时信息卡跟随 | `HtmlMarkerLayer` |
| `basic/officialPointCluster.js` | 企业/车辆/事件点聚合 | `PointClusterLayer` |
| `effect/dynamicWall.js` | 路权区、运营区、禁行区动态围栏 | `FenceWallLayer` |
| `effect/gradientWall.js` | 运营区域/电子围栏渐变墙 | `FenceWallMaterial` |
| `effect/radar.js` | 风险事件、重点对象扫描 | `RadarScanEffect` |
| `expand/ripple.js` | 告警点/事故点扩散波纹 | `PulseMarker` |
| `expand/heatMap.js` | 市级告警/事故/车辆密度热力 | `HeatMapLayer` |
| `effect/postProcessStage.js` | 选中对象描边、Bloom、高亮 | `HighlightManager` / `PostProcessManager` |
| `layer/mapfilterLayer.js` | 高德暗色科技底图视觉调校 | `BaseMapTheme` |
| `tools/DrawAndExportGeojson.js` | 路权区域、运行区域、禁行区绘制维护 | 独立“区域编辑工具” |

## 3. 第二优先级：有价值但不需要一期全部实现

| 参考文件 | 用途 | 建议 |
|---|---|---|
| `expand/3DheatMap.js` | 三维风险热力 | 风险专题视图增强，不作为首页默认效果 |
| `effect/radarEmission.js` | 更强的雷达/发射扫描表现 | 与 `radar.js` 二选一即可 |
| `basic/loadModel.js` | GLB/模型加载 | 用于无人车模型加载，保留模型部分，不采用其 3D Tiles 示例部分 |
| `expand/cityLight.js` | 城市建筑渐变/扫描光效 | 只参考 `CustomShader`，当前项目不恢复 3D Tiles 主逻辑 |
| `expand/cesiumAndThree.js` | Cesium + Three.js 双画布/相机同步 | 仅作为未来特殊特效 Overlay 预研，不进入一期核心架构 |

## 4. 三级驾驶舱对应关系

### 国家级
优先使用：
- `boundBorder`
- `geojsonFace`
- `gradienGeojsonFace`
- `flyLine`
- `postProcessStage`

目标效果：省域发光、选中高亮、少量飞线、地图与两侧图表联动。

### 省级
优先使用：
- `geojsonFace`
- `gradienGeojsonFace`
- `flyLine`
- `radar`
- `heatMap`
- `officialPointCluster`

目标效果：地市分区、重点地市高亮、风险热力、企业聚合、动态路线。

### 市级
优先使用：
- `routeNavigation`
- `cssElementTrack`
- `officialPointCluster`
- `dynamicWall`
- `gradientWall`
- `ripple`
- `heatMap`
- `transportLine`
- `DrawAndExportGeojson`

目标效果：车辆运行、轨迹跟随、路权/运营区、风险事件、道路流光和地图编辑。

## 5. 不建议纳入当前项目的原 Cesium 示例

已主动排除以下类型，避免把引擎再次做杂：
- 火灾、烟雾、雨雪、体积云等非核心环境特效
- 视域分析、水体等与无人车监管关系弱的功能
- 百度、ArcGIS 等重复底图方案
- 大量工具型计算示例
- 与当前“不使用 3D Tiles 主场景”方向冲突的整套 3D Tiles Demo
- 自动漫游、键盘漫游等演示性质能力

## 6. 对现有 GeoEngine 的推荐落位

```text
GeoEngine
├─ core/
│  ├─ SceneManager
│  ├─ CameraController
│  ├─ LayerManager
│  └─ InteractionManager
├─ geo/
│  ├─ RegionLayer
│  ├─ BoundaryLayer
│  ├─ RoadNetworkLayer
│  └─ GeoJsonLayer
├─ effects/
│  ├─ FlowRoute
│  ├─ RadarScanEffect
│  ├─ HeatMapLayer
│  ├─ FenceWallLayer
│  ├─ PulseMarker
│  └─ RegionGlow
├─ objects/
│  ├─ VehicleLayer
│  ├─ EnterpriseLayer
│  ├─ RiskEventLayer
│  └─ HtmlMarkerLayer
└─ animation/
   ├─ DrillTransition
   ├─ TrackAnimation
   └─ VehicleFollow
```

## 7. 版权说明

原代码来自用户提供的 `three-cesium-examples` 压缩包，原仓库 License 已随本包保留。二次使用具体代码时仍需遵守原项目及其引用资源的许可要求。
