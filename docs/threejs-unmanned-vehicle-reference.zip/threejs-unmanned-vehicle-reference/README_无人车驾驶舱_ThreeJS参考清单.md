# 无人车国家—省—市监管驾驶舱：Three.js 精选视觉参考包

## 1. 定位

本包不是要把 Three.js 作为第二套主地图引擎，而是只保留对当前无人车监管驾驶舱真正有价值的 Three.js 视觉/动画实现。

使用原则：

> **优先把实现思路、Shader 和动画逻辑迁移到 Cesium `Primitive / Material / CustomShader / PostProcessStage`；只有 Cesium 难以实现的少数特效，未来才考虑 Three Overlay。**

因此本包是“视觉算法参考包”，不建议直接合并到生产代码。

> 注意：部分原示例依赖作者外部资源地址、`FILE_HOST`、模型或纹理，本包保留源码和预览，不保证单独运行。

## 2. 第一优先级：最值得迁移到 Cesium

| Three.js 参考文件 | 可借鉴的能力 | Cesium 目标实现 |
|---|---|---|
| `other/areaMap.js` | 3D 行政区、区域下钻、区域选中动画 | `RegionLayer` + `DrillTransition` |
| `expand/geoBorder.js` | 行政边界动态/发光纹理 | `RegionGlow` / `PolylineMaterial` |
| `application/flowLine.js` | 贴图流光路线 | `FlowRoute` |
| `application/diffuseLine.js` | 扩散/飞线动态 | 国家、省级关系线效果 |
| `application/radarScan.js` | 雷达扫描区域 | `RadarScanEffect` |
| `application/roadShader.js` | 科技道路 Shader / Bloom | `RoadNetworkLayer` + Cesium Material |
| `application/buildingLine.js` | 建筑边缘线框强化 | `BuildingLayer` / 模型高亮 |
| `application/white_model.js` | 白模城市视觉 | 市级轻量城市白模设计参考 |
| `shader/buildGradient.js` | 建筑高度渐变 | Cesium `CustomShader` |
| `shader/cityLine.js` | 城市线框科技效果 | `BuildingLayer` 线框层 |
| `shader/cityMoveLight.js` | 建筑扫描光带 | Cesium `CustomShader` 动态光带 |
| `shader/fenceShader.js` | 发光电子围栏 | Cesium `WallGeometry + Material` |
| `shader/circleWave.js` | 扩散波/扫描圈 | `PulseMarker` / `ScanEffect` |
| `shader/planeScan.js` | 平面扫描纹理 | 区域扫描/重点监管区效果 |
| `basic/multOutlinePass.js` | 多对象描边选中 | Cesium Silhouette/PostProcess |
| `application/modelBorder.js` | 模型边缘提取与高亮 | 车辆/企业模型选中效果参考 |

## 3. 对三级驾驶舱的使用建议

### 国家级
可借：
- `areaMap.js`：国家→省下钻的状态/动画逻辑
- `geoBorder.js`：中国/省域发光边界
- `flowLine.js` / `diffuseLine.js`：跨省关系流线
- `circleWave.js`：重点省份轻量扩散效果

不要把 Three.js 地图直接换掉 Cesium 地图。

### 省级
可借：
- `areaMap.js`：省→市区域层级切换
- `radarScan.js`：高风险地市扫描
- `planeScan.js`：重点区域扫描
- `flowLine.js`：地市之间关系线

### 市级
可借：
- `roadShader.js`：发光城市路网
- `white_model.js`：城市白模风格
- `buildingLine.js` / `cityLine.js`：建筑线框
- `buildGradient.js` / `cityMoveLight.js`：建筑渐变和扫描光
- `fenceShader.js`：路权/禁行区发光围栏
- `multOutlinePass.js` / `modelBorder.js`：企业、车辆选中高亮

## 4. 建议迁移方式

```text
Three.js ShaderMaterial      → Cesium Material / CustomShader
Three.js ExtrudeGeometry     → Cesium PolygonGeometry / GroundPrimitive
Three.js Line/Tube           → Cesium Polyline / Primitive
Three.js OutlinePass         → Cesium SilhouetteStage / PostProcessStage
Three.js Radar Plane         → Cesium Primitive / PostProcessStage
Three.js Fence Mesh          → Cesium WallGeometry
Three.js CSS2D               → Cesium HTML Overlay / SceneTransforms
Three.js GSAP Camera Tween   → Cesium camera.flyTo + SceneManager 状态切换
```

## 5. 明确不纳入的 Three.js 内容

本包已排除：
- 游戏、人物控制、物理引擎
- 音频可视化
- 大量纯艺术 Shader
- 火焰、烟雾、雪花等非监管核心特效
- 宇宙、行星、黑洞等无关效果
- 与无人车监管无直接关系的模型展示
- 高德 + Three、Mapbox + Three 等会形成第二套 GIS 主引擎的方案

## 6. Three Overlay 的使用边界

当前不启用双引擎。仅保留未来可能的架构接口：

```text
GeoEngine
└─ ThreeOverlayRenderer (optional / disabled by default)
```

只有在复杂 GPU 粒子、特殊 WebGPU Shader 等 Cesium 实现成本明显更高时才考虑启用。

## 7. 版权说明

原代码来自用户提供的 `three-cesium-examples` 压缩包，原仓库 License 已随本包保留。部分示例可能依赖第三方模型、纹理或外部资源，实际商用前需要单独核对相应资源许可。
